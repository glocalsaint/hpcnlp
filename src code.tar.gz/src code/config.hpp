#ifndef CONFIG_HPP
#define CONFIG_HPP
#include<string>
#include <sqlite3.h>
using namespace std;
namespace config{  
  
  //writes output to file if set to 1 otherwise writes to console.
  const int    WRITE_OUTPUT_TO_FILE = 0;
  const int    ALLOW_TIME_LOGGING  = 1;
  const int    WRITE_WSD_TO_FILE = 0;

  const int    ROUNDROBINSIZE = 500;
  const int    STRING_LENGTH = 30;
  const int    NUMWORDS = 20;
  const int    NUMOF_FLWORDS = 70000;
  const string inputfiles_location = "/work/scratch/vv52zasu/inputfiles";
  const string outputfiles_location = "/work/scratch/vv52zasu/outputfiles/writetoconsole/256_2";

  static  int     MIN_NUM_OCCURRENCES                 = 10;        // 10 in HyperLex paper
  static  int     MIN_FIRST_ORDER_COOCCURRENCE_COUNT  = 5;         // 5 in HyperLex paper
  static  double  MAX_EDGE_WEIGHT                     = 0.9;       // 0.9 in HyperLex paper
  static  int     ROOT_HUB_MIN_NUM_EDGES              = 6;         // 6 in HyperLex paper
  static  double  ROOT_HUB_AVG_EDGE_WEIGHT_LIMIT_EXCL = 0.8;       // 0.8 in HyperLex paper 

  //sqlite3 *db;
}  
#endif
