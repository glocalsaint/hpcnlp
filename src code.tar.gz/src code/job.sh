#!/bin/bash
#SBATCH -J hpc4nlp256 #JOBNAME
#SBATCH --mail-user=glocalsaint@gmail.com
#SBATCH --mail-type=ALL
#SBATCH -e /work/scratch/vv52zasu/256_2.err #error file
#SBATCH -o /work/scratch/vv52zasu/256_2.out #output file
#SBATCH -n 256     # Number of tasks
#SBATCH -c 2 #Number of cores per process(task)
#SBATCH --mem-per-cpu=4000  # Main memory in MByte per MPI task
#SBATCH --exclusive
#SBATCH -t 60 # Time in minutes
cd /home/vv52zasu/mpi/src/
module load gcc openmpi/gcc boost
mpirun -np 256 hyperlexmain
